#import <UIKit/UIKit.h>

// Forward declarations of private Apple SpringBoard & CarPlay classes
@interface SBApplication : NSObject
- (NSString *)bundleIdentifier;
- (BOOL)isCarPlaySupported;
@end

@interface CRSUIApplicationController : NSObject
- (BOOL)isApplicationSupported:(id)app;
@end

// Whitelist FahrulAuto bundle ID
static NSString * const kTargetBundleID = @"com.kododake.fahrulauto";

%hook SBApplication

- (BOOL)isCarPlaySupported {
    if ([[self bundleIdentifier] isEqualToString:kTargetBundleID]) {
        return YES; // Force SpringBoard to display FahrulAuto on CarPlay screen
    }
    return %orig;
}

%end

%hook CRSUIApplicationController

- (BOOL)isApplicationSupported:(id)app {
    if ([app respondsToSelector:@selector(bundleIdentifier)]) {
        if ([[app bundleIdentifier] isEqualToString:kTargetBundleID]) {
            return YES;
        }
    }
    return %orig;
}

%end

%ctor {
    NSLog(@"[FahrulAuto CarPlay Bridge] Loaded into SpringBoard!");
}
