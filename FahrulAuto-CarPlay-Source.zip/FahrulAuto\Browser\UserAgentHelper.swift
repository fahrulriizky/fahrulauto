import Foundation
import WebKit

enum UserAgentHelper {
    static func configure(webView: WKWebView, for url: URL) {
        let host = url.host?.lowercased() ?? ""
        if host.contains("whatsapp") {
            // Apply Desktop Chrome Windows UA so WhatsApp Web renders barcode
            webView.customUserAgent = AppConstants.desktopUserAgent
        } else {
            webView.customUserAgent = nil
        }
    }
}
