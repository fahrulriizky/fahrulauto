import UIKit

protocol CarPlayDashboardDelegate: AnyObject {
    func dashboardDidSelectShortcut(_ shortcut: ShortcutItem)
}

final class CarPlayDashboardView: UIView, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    weak var delegate: CarPlayDashboardDelegate?
    
    private let shortcuts = ShortcutCatalog.items
    private var collectionView: UICollectionView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupGrid()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupGrid()
    }
    
    private func setupGrid() {
        backgroundColor = UIColor(red: 0.05, green: 0.04, blue: 0.08, alpha: 1.0) // Deep obsidian purple
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.sectionInset = UIEdgeInsets(top: 24, left: 24, bottom: 24, right: 24)
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(CarPlayShortcutCell.self, forCellWithReuseIdentifier: CarPlayShortcutCell.reuseID)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(collectionView)
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
    
    // MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return shortcuts.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CarPlayShortcutCell.reuseID, for: indexPath) as! CarPlayShortcutCell
        let item = shortcuts[indexPath.item]
        cell.configure(with: item)
        return cell
    }
    
    // MARK: - UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // 4 items per row on widescreen car displays
        let availableWidth = collectionView.bounds.width - 48 - (16 * 3)
        let width = max(110, floor(availableWidth / 4))
        return CGSize(width: width, height: 95)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = shortcuts[indexPath.item]
        delegate?.dashboardDidSelectShortcut(item)
    }
}

final class CarPlayShortcutCell: UICollectionViewCell {
    static let reuseID = "CarPlayShortcutCell"
    
    private let iconImageView = UIImageView()
    private let titleLabel = UILabel()
    private let cardContainer = UIView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
    }
    
    private func setupViews() {
        cardContainer.backgroundColor = UIColor(white: 0.16, alpha: 0.9)
        cardContainer.layer.cornerRadius = 14
        cardContainer.layer.borderWidth = 1
        cardContainer.layer.borderColor = UIColor(white: 0.28, alpha: 0.6).cgColor
        cardContainer.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(cardContainer)
        
        iconImageView.contentMode = .scaleAspectFit
        iconImageView.tintColor = .white
        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        cardContainer.addSubview(iconImageView)
        
        titleLabel.font = .systemFont(ofSize: 13, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        cardContainer.addSubview(titleLabel)
        
        NSLayoutConstraint.activate([
            cardContainer.topAnchor.constraint(equalTo: contentView.topAnchor),
            cardContainer.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            cardContainer.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            cardContainer.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            
            iconImageView.centerXAnchor.constraint(equalTo: cardContainer.centerXAnchor),
            iconImageView.topAnchor.constraint(equalTo: cardContainer.topAnchor, constant: 14),
            iconImageView.widthAnchor.constraint(equalToConstant: 34),
            iconImageView.heightAnchor.constraint(equalToConstant: 34),
            
            titleLabel.topAnchor.constraint(equalTo: iconImageView.bottomAnchor, constant: 8),
            titleLabel.leadingAnchor.constraint(equalTo: cardContainer.leadingAnchor, constant: 4),
            titleLabel.trailingAnchor.constraint(equalTo: cardContainer.trailingAnchor, constant: -4)
        ])
    }
    
    func configure(with item: ShortcutItem) {
        titleLabel.text = item.title
        let config = UIImage.SymbolConfiguration(pointSize: 22, weight: .bold)
        iconImageView.image = UIImage(systemName: item.iconName, withConfiguration: config)
        
        // Highlight border with brand accent
        if item.id == "whatsapp" {
            cardContainer.layer.borderColor = UIColor(red: 0.15, green: 0.83, blue: 0.40, alpha: 0.7).cgColor
        } else if item.id == "netflix" {
            cardContainer.layer.borderColor = UIColor(red: 0.90, green: 0.04, blue: 0.08, alpha: 0.7).cgColor
        } else {
            cardContainer.layer.borderColor = UIColor(white: 0.28, alpha: 0.6).cgColor
        }
    }
}
