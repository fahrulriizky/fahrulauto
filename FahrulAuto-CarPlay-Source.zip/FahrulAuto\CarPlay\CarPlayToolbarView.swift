import UIKit

protocol CarPlayToolbarDelegate: AnyObject {
    func toolbarDidTapBack()
    func toolbarDidTapForward()
    func toolbarDidTapReload()
    func toolbarDidTapHome()
}

final class CarPlayToolbarView: UIView {
    weak var delegate: CarPlayToolbarDelegate?
    
    private let backButton = UIButton(type: .system)
    private let forwardButton = UIButton(type: .system)
    private let reloadButton = UIButton(type: .system)
    private let homeButton = UIButton(type: .system)
    private let titleLabel = UILabel()
    private let subtitleLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
    }
    
    private func setupViews() {
        backgroundColor = UIColor(white: 0.1, alpha: 0.95)
        
        // Brand Title
        titleLabel.text = "FahrulAuto"
        titleLabel.font = .systemFont(ofSize: 17, weight: .bold)
        titleLabel.textColor = .white
        
        subtitleLabel.text = "~Sampurasun~"
        subtitleLabel.font = .systemFont(ofSize: 12, weight: .medium)
        subtitleLabel.textColor = UIColor(red: 0.85, green: 0.70, blue: 1.0, alpha: 1.0) // Soft Purple
        
        let brandStack = UIStackView(arrangedSubviews: [titleLabel, subtitleLabel])
        brandStack.axis = .vertical
        brandStack.spacing = 1
        brandStack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(brandStack)
        
        // Navigation Buttons
        configureButton(homeButton, icon: "house.fill", action: #selector(homeTapped))
        configureButton(backButton, icon: "chevron.backward", action: #selector(backTapped))
        configureButton(forwardButton, icon: "chevron.forward", action: #selector(forwardTapped))
        configureButton(reloadButton, icon: "arrow.clockwise", action: #selector(reloadTapped))
        
        let buttonStack = UIStackView(arrangedSubviews: [homeButton, backButton, forwardButton, reloadButton])
        buttonStack.axis = .horizontal
        buttonStack.spacing = 16
        buttonStack.distribution = .equalSpacing
        buttonStack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(buttonStack)
        
        NSLayoutConstraint.activate([
            brandStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            brandStack.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            buttonStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            buttonStack.centerYAnchor.constraint(equalTo: centerYAnchor),
            buttonStack.heightAnchor.constraint(equalToConstant: 36)
        ])
    }
    
    private func configureButton(_ btn: UIButton, icon: String, action: Selector) {
        let config = UIImage.SymbolConfiguration(pointSize: 18, weight: .semibold)
        let image = UIImage(systemName: icon, withConfiguration: config)
        btn.setImage(image, for: .normal)
        btn.tintColor = .white
        btn.backgroundColor = UIColor(white: 0.25, alpha: 0.8)
        btn.layer.cornerRadius = 8
        btn.contentEdgeInsets = UIEdgeInsets(top: 6, left: 12, bottom: 6, right: 12)
        btn.addTarget(self, action: action, for: .touchUpInside)
    }
    
    @objc private func homeTapped() { delegate?.toolbarDidTapHome() }
    @objc private func backTapped() { delegate?.toolbarDidTapBack() }
    @objc private func forwardTapped() { delegate?.toolbarDidTapForward() }
    @objc private func reloadTapped() { delegate?.toolbarDidTapReload() }
    
    func updateNavigationState(canGoBack: Bool, canGoForward: Bool) {
        backButton.isEnabled = canGoBack
        backButton.alpha = canGoBack ? 1.0 : 0.4
        forwardButton.isEnabled = canGoForward
        forwardButton.alpha = canGoForward ? 1.0 : 0.4
    }
}
