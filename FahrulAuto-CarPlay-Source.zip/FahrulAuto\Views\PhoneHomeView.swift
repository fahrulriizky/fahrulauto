import SwiftUI
import WebKit

struct PhoneHomeView: View {
    @State private var selectedShortcut: ShortcutItem?
    @State private var isShowingBrowser: Bool = false
    @State private var currentURLString: String = AppConstants.defaultURL
    
    private let columns = [
        GridItem(.adaptive(minimum: 100), spacing: 16)
    ]
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Background
                LinearGradient(
                    colors: [Color(red: 0.05, green: 0.04, blue: 0.09), Color(red: 0.12, green: 0.08, blue: 0.20)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Header Brand
                    VStack(spacing: 6) {
                        Text("FahrulAuto")
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                        
                        Text(AppConstants.subtitle)
                            .font(.system(size: 15, weight: .medium))
                            .foregroundColor(Color(red: 0.85, green: 0.70, blue: 1.0))
                    }
                    .padding(.top, 10)
                    
                    // CarPlay Status Pill
                    HStack(spacing: 8) {
                        Circle()
                            .fill(Color.green)
                            .frame(width: 8, height: 8)
                        Text("CarPlay Ready")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .background(Color.white.opacity(0.12))
                    .clipShape(Capsule())
                    
                    // Shortcuts Grid
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 16) {
                            ForEach(ShortcutCatalog.items) { item in
                                Button {
                                    currentURLString = item.webURL
                                    isShowingBrowser = true
                                } label: {
                                    VStack(spacing: 10) {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                                .fill(Color.white.opacity(0.10))
                                                .frame(width: 68, height: 68)
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                                                        .stroke(Color.white.opacity(0.2), lineWidth: 1)
                                                )
                                            
                                            Image(systemName: item.iconName)
                                                .font(.system(size: 28, weight: .semibold))
                                                .foregroundColor(.white)
                                        }
                                        
                                        Text(item.title)
                                            .font(.system(size: 13, weight: .medium))
                                            .foregroundColor(.white)
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 10)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $isShowingBrowser) {
                PhoneBrowserSheet(urlString: currentURLString)
            }
        }
    }
}

struct PhoneBrowserSheet: View {
    let urlString: String
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            PhoneWebView(urlString: urlString)
                .navigationTitle("FahrulAuto Browser")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Close") { dismiss() }
                    }
                }
        }
    }
}

struct PhoneWebView: UIViewRepresentable {
    let urlString: String
    
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        let webView = WKWebView(frame: .zero, configuration: config)
        if let url = URL(string: urlString) {
            UserAgentHelper.configure(webView: webView, for: url)
            webView.load(URLRequest(url: url))
        }
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
