# FahrulAuto CarPlay (iOS)

Dedicated Apple CarPlay Browser & Shortcut Launcher for iPhone and CarPlay Headunits.

---

## 📁 Struktur Project

```
FahrulAuto-CarPlay/
├── FahrulAuto.xcodeproj/             # Xcode Project (Open di macOS / Xcode)
│   └── project.pbxproj
├── FahrulAuto/
│   ├── App/
│   │   ├── AppDelegate.swift          # Lifecycle & Scene routing
│   │   ├── SceneDelegate.swift        # iPhone Display Window
│   │   └── CarPlaySceneDelegate.swift # CarPlay Screen Window (CPWindow)
│   ├── CarPlay/
│   │   ├── CarPlayBrowserViewController.swift # In-Car WKWebView + Controller
│   │   ├── CarPlayDashboardView.swift         # Grid 8 Shortcut di layar mobil
│   │   └── CarPlayToolbarView.swift           # Bar kontrol (Home, Back, Next, Reload)
│   ├── Browser/
│   │   └── UserAgentHelper.swift      # Auto Desktop UA khusus WhatsApp Web QR
│   ├── Models/
│   │   └── ShortcutItem.swift         # 8 Shortcut (WA, YT, TikTok, IG, FB, Netflix, X, Threads)
│   ├── Views/
│   │   └── PhoneHomeView.swift        # Layar aplikasi di HP iPhone
│   ├── Config/
│   │   └── AppConstants.swift         # Nama app, subtitle (~Sampurasun~), UA
│   └── Resources/
│       ├── Info.plist                 # Deklarasi CarPlay scene manifest
│       ├── FahrulAuto.entitlements    # Entitlement carplay-maps & private
│       └── Assets.xcassets/           # AppIcon HD 1024x1024
└── Tweak_CarBridge/                   # Alternatif Tweak Jailbreak (Theos)
    ├── Makefile
    ├── control
    └── Tweak.x                        # Hook SpringBoard isCarPlaySupported
```

---

## 🚗 Cara Kerja Deteksi di Apple CarPlay

1. **Bypass Entitlement Resmi (Tanpa Jailbreak):**
   Aplikasi menggunakan scene `CPTemplateApplicationSceneSessionRoleApplication` dengan `com.apple.developer.carplay-maps`. Kategori navigasi memberikan akses `CPWindow` penuh ke layar eksternal mobil, sehingga `WKWebView` dapat dirender langsung tanpa batasan template kaku Apple.

2. **WhatsApp Web Barcode Scanning:**
   `UserAgentHelper.swift` secara otomatis menginjeksi **Windows Desktop Chrome User-Agent** ketika membuka `web.whatsapp.com`. Hal ini mencegah WhatsApp menampilkan halaman "Unduh Aplikasi Mobile" dan langsung memunculkan kode QR/Barcode di layar mobil.

3. **Metode TrollStore / Jailbreak:**
   File `FahrulAuto.entitlements` sudah menyertakan `com.apple.private.carplay.applications`. Untuk pengguna TrollStore (iOS 14.0 - 17.0), aplikasi ini langsung terdeteksi di CarPlay saat diinstal sebagai IPA.
   Bagi pengguna Jailbreak penuh, folder `Tweak_CarBridge/` menyediakan tweak Theos untuk mem-bypass whitelist SpringBoard secara sistemik.

---

## 🛠️ Cara Build & Install ke iPhone

### Opsi 1: Menggunakan Xcode (macOS)
1. Buka folder ini di Mac, klik dua kali `FahrulAuto.xcodeproj`.
2. Pilih Signing Team Anda di tab **Signing & Capabilities**.
3. Sambungkan iPhone, pilih target perangkat, lalu klik **Run (Cmd + R)**.

### Opsi 2: Menggunakan TrollStore (iOS 14 - 17.0)
1. Build file menjadi `.ipa`.
2. Kirim file `.ipa` ke iPhone via AirDrop / Share.
3. Buka dengan **TrollStore** -> **Install**.
4. Ikon `FahrulAuto` otomatis muncul di dashboard CarPlay saat terhubung ke mobil.

### Opsi 3: Menggunakan Sideloadly / AltStore (Windows / Mac)
1. Download dan buka Sideloadly di PC.
2. Drag file `.ipa` hasil build, masukkan Apple ID Anda.
3. Install ke iPhone dan aktifkan Developer Mode di Settings iOS.
