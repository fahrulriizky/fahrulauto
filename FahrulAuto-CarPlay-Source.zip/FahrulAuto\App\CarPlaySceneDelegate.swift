import UIKit
import CarPlay

final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate, CPTemplateApplicationDashboardSceneDelegate {
    
    var interfaceController: CPInterfaceController?
    var carWindow: CPWindow?
    private var browserVC: CarPlayBrowserViewController?
    
    // MARK: - CPTemplateApplicationSceneDelegate
    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene, 
                                  didConnect interfaceController: CPInterfaceController, 
                                  to window: CPWindow) {
        self.interfaceController = interfaceController
        self.carWindow = window
        
        let rootVC = CarPlayBrowserViewController()
        self.browserVC = rootVC
        
        window.rootViewController = rootVC
        
        // Setup MapTemplate baseline required by CarPlay navigation apps to access full custom UIWindow
        let mapTemplate = CPMapTemplate()
        interfaceController.setRootTemplate(mapTemplate, animated: false, completion: nil)
    }
    
    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene, 
                                  didDisconnect interfaceController: CPInterfaceController, 
                                  from window: CPWindow) {
        self.interfaceController = nil
        self.carWindow = nil
        self.browserVC = nil
    }
}
