import Foundation

struct ShortcutItem: Identifiable, Hashable {
    let id: String
    let title: String
    let iconName: String      // SF Symbol or asset
    let systemColorHex: String
    let webURL: String
    let appScheme: String?
    let requiresDesktopMode: Bool
}

enum ShortcutCatalog {
    static let items: [ShortcutItem] = [
        ShortcutItem(
            id: "youtube",
            title: "YouTube",
            iconName: "play.rectangle.fill",
            systemColorHex: "#FF0000",
            webURL: "https://www.youtube.com/",
            appScheme: "youtube://",
            requiresDesktopMode: false
        ),
        ShortcutItem(
            id: "tiktok",
            title: "TikTok",
            iconName: "music.note",
            systemColorHex: "#010101",
            webURL: "https://www.tiktok.com/",
            appScheme: "snssdk1233://",
            requiresDesktopMode: false
        ),
        ShortcutItem(
            id: "instagram",
            title: "Instagram",
            iconName: "camera.fill",
            systemColorHex: "#E1306C",
            webURL: "https://www.instagram.com/",
            appScheme: "instagram://",
            requiresDesktopMode: false
        ),
        ShortcutItem(
            id: "facebook",
            title: "Facebook",
            iconName: "person.2.fill",
            systemColorHex: "#1877F2",
            webURL: "https://www.facebook.com/",
            appScheme: "fb://",
            requiresDesktopMode: false
        ),
        ShortcutItem(
            id: "whatsapp",
            title: "WhatsApp",
            iconName: "message.fill",
            systemColorHex: "#25D366",
            webURL: "https://web.whatsapp.com/",
            appScheme: "whatsapp://",
            requiresDesktopMode: true // Forces desktop UA so QR scan works directly
        ),
        ShortcutItem(
            id: "netflix",
            title: "Netflix",
            iconName: "film.fill",
            systemColorHex: "#E50914",
            webURL: "https://www.netflix.com/id/Login?hnjr=3&mqso=60178549",
            appScheme: "nflx://",
            requiresDesktopMode: false
        ),
        ShortcutItem(
            id: "x",
            title: "X",
            iconName: "bolt.fill",
            systemColorHex: "#000000",
            webURL: "https://x.com/?lang=id",
            appScheme: "twitter://",
            requiresDesktopMode: false
        ),
        ShortcutItem(
            id: "threads",
            title: "Threads",
            iconName: "at",
            systemColorHex: "#101010",
            webURL: "https://www.threads.com/?hl=id",
            appScheme: "barcelona://",
            requiresDesktopMode: false
        )
    ]
}
