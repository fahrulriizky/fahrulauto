import Foundation

enum AppConstants {
    static let appName = "FahrulAuto"
    static let subtitle = "~Sampurasun~"
    static let bundleID = "com.kododake.fahrulauto"
    static let defaultURL = "https://www.google.com"
    
    // User Agent: Windows 11 Desktop Chrome UA (required for WhatsApp Web QR barcode scan)
    static let desktopUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    
    // Default Mobile User Agent
    static let mobileUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
}
