import UIKit
import WebKit

final class CarPlayBrowserViewController: UIViewController, WKNavigationDelegate, CarPlayToolbarDelegate, CarPlayDashboardDelegate {
    
    private let toolbar = CarPlayToolbarView()
    private let dashboardView = CarPlayDashboardView()
    private var webView: WKWebView!
    
    private var isShowingDashboard: Bool = true {
        didSet {
            dashboardView.isHidden = !isShowingDashboard
            webView.isHidden = isShowingDashboard
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    private func setupUI() {
        view.backgroundColor = .black
        
        // 1. Setup Toolbar
        toolbar.delegate = self
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toolbar)
        
        // 2. Setup WKWebView
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs
        
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.backgroundColor = .black
        webView.isOpaque = false
        webView.scrollView.bounces = true
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        
        // 3. Setup Dashboard Grid
        dashboardView.delegate = self
        dashboardView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(dashboardView)
        
        NSLayoutConstraint.activate([
            // Toolbar at top
            toolbar.topAnchor.constraint(equalTo: view.topAnchor),
            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            toolbar.heightAnchor.constraint(equalToConstant: 48),
            
            // WebView filling rest of display
            webView.topAnchor.constraint(equalTo: toolbar.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            // Dashboard overlaying WebView initially
            dashboardView.topAnchor.constraint(equalTo: toolbar.bottomAnchor),
            dashboardView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            dashboardView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            dashboardView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        isShowingDashboard = true
    }
    
    func navigate(to urlString: String) {
        guard let url = URL(string: urlString) else { return }
        UserAgentHelper.configure(webView: webView, for: url)
        
        let request = URLRequest(url: url)
        webView.load(request)
        isShowingDashboard = false
    }
    
    // MARK: - CarPlayDashboardDelegate
    func dashboardDidSelectShortcut(_ shortcut: ShortcutItem) {
        navigate(to: shortcut.webURL)
    }
    
    // MARK: - CarPlayToolbarDelegate
    func toolbarDidTapHome() {
        isShowingDashboard = true
    }
    
    func toolbarDidTapBack() {
        if webView.canGoBack {
            webView.goBack()
        } else {
            isShowingDashboard = true
        }
    }
    
    func toolbarDidTapForward() {
        if webView.canGoForward {
            webView.goForward()
        }
    }
    
    func toolbarDidTapReload() {
        webView.reload()
    }
    
    // MARK: - WKNavigationDelegate
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        toolbar.updateNavigationState(canGoBack: webView.canGoBack, canGoForward: webView.canGoForward)
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let targetURL = navigationAction.request.url {
            UserAgentHelper.configure(webView: webView, for: targetURL)
        }
        decisionHandler(.allow)
    }
}
